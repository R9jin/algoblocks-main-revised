// frontend/src/utils/errorTranslator.js

export const translatePythonError = (rawErrorMessage) => {
  if (!rawErrorMessage) return { rootCause: "Unknown Error", solution: "Check your code for typos." };

  const msg = String(rawErrorMessage);
  let rootCause = "Syntax or Runtime Error";
  let solution = "Try copying this error and checking lines nearby for typos.";

  // ==========================================
  // SYNTAX & STRUCTURE ERRORS
  // ==========================================
  if (msg.includes("EOL while scanning string literal") || msg.includes("unterminated string literal")) {
    rootCause = "String literal was not properly closed.";
    solution = "Add the missing quotation mark (' or \") at the end of the string.";
  } 
  else if (msg.includes("unexpected EOF while parsing") || msg.includes("unexpected EOF")) {
    rootCause = "The code ended before all blocks were closed.";
    solution = "Check for a missing closing parenthesis ')', bracket ']', or brace '}'.";
  } 
  else if (msg.includes("expected ':'") || msg.includes("expected a ':'")) {
    rootCause = "Missing colon in a control structure.";
    solution = "Add a colon (:) at the end of your 'if', 'for', 'while', or 'def' statement.";
  } 
  else if (msg.includes("invalid syntax")) {
    rootCause = "Python cannot understand this line's structure.";
    solution = "Check for missing colons (:), unclosed parentheses/quotes, or misspelled/misplaced keywords nearby.";
  } 

  // ==========================================
  // INDENTATION & WHITESPACE
  // ==========================================
  else if (msg.includes("TabError") || msg.includes("inconsistent use of tabs and spaces")) {
    rootCause = "Mixed indentation styles detected.";
    solution = "Python strictly requires using either all spaces or all tabs. Convert all indentation to spaces.";
  }
  else if (msg.includes("IndentationError") || msg.includes("expected an indented block")) {
    rootCause = "Improper spacing at the start of a line.";
    solution = "Ensure code inside loops, conditionals, and functions is indented consistently.";
  } 
  
  // ==========================================
  // VARIABLES, NAMES & SCOPE
  // ==========================================
  else if (msg.includes("NameError") || msg.includes("is not defined")) {
    const match = msg.match(/name '([^']+)' is not defined/);
    const varName = match ? match[1] : "a variable";
    rootCause = `The identifier '${varName}' has not been declared.`;
    solution = `Define '${varName}' before using it, check your spelling, or ensure strings have quotation marks.`;
  } 
  else if (msg.includes("UnboundLocalError")) {
    const match = msg.match(/local variable '([^']+)' referenced before assignment/);
    const varName = match ? match[1] : "a variable";
    rootCause = `Attempted to access local variable '${varName}' before assigning it a value.`;
    solution = `Assign a value to '${varName}' earlier in the function, or use the 'global' keyword if it exists outside the function.`;
  }
  
  // ==========================================
  // TYPES & COMPATIBILITY
  // ==========================================
  else if (msg.includes("TypeError: unsupported operand")) {
    rootCause = "Invalid operation between incompatible data types.";
    solution = "Ensure you are performing math on numbers, not mixing text and numbers.";
  } 
  else if (msg.includes("TypeError: can only concatenate str") || msg.includes("must be str, not int")) {
    rootCause = "Attempted to directly combine text (string) and numbers (int).";
    solution = "Wrap your number in str() before adding it to text (e.g., str(5)).";
  } 
  else if (msg.includes("TypeError") && msg.includes("object is not callable")) {
    const match = msg.match(/'([^']+)' object is not callable/);
    const objName = match ? match[1] : "An";
    rootCause = `Attempted to call a ${objName} as if it were a function.`;
    solution = `Remove the parentheses '()' after the variable, as it is not a function.`;
  }
  else if (msg.includes("TypeError") && msg.includes("object is not iterable")) {
    const match = msg.match(/'([^']+)' object is not iterable/);
    const objName = match ? match[1] : "An";
    rootCause = `Attempted to loop over a ${objName}, which is a single value.`;
    solution = `Ensure the variable you are looping over is a collection, like a list, string, or dictionary.`;
  }

  // ==========================================
  // LISTS, DICTIONARIES & TUPLES
  // ==========================================
  else if (msg.includes("IndexError: list index out of range")) {
    rootCause = "Attempted to access a list position that does not exist.";
    solution = "Check your index value. Remember that lists start counting at 0, and the maximum index is length - 1.";
  } 
  else if (msg.includes("KeyError")) {
    const match = msg.match(/KeyError: (.*)/);
    const keyName = match ? match[1] : "a key";
    rootCause = `The key ${keyName} was not found in the dictionary.`;
    solution = `Add the key to the dictionary before accessing it, or use the dict.get() method.`;
  } 
  
  // ==========================================
  // MATH & VALUES
  // ==========================================
  else if (msg.includes("ZeroDivisionError") || msg.includes("division by zero")) {
    rootCause = "Mathematical error: Division by zero.";
    solution = "Add a conditional check to ensure the divisor is not 0 before dividing.";
  } 
  else if (msg.includes("ValueError: invalid literal for int()")) {
    const match = msg.match(/invalid literal for int\(\) with base \d+: '([^']+)'/);
    const badVal = match ? match[1] : "the text";
    rootCause = `Failed to convert '${badVal}' into an integer.`;
    solution = `Ensure the text only contains whole numbers before using int().`;
  } 
  
  // ==========================================
  // ADVANCED: RECURSION & MEMORY
  // ==========================================
  else if (msg.includes("RecursionError") || msg.includes("maximum recursion depth exceeded")) {
    rootCause = "Infinite recursion detected. The function called itself too many times.";
    solution = "Verify your recursive 'base case' to ensure the function eventually stops calling itself.";
  }
  else if (msg.includes("MemoryError")) {
    rootCause = "Out of Memory. The program consumed too much RAM.";
    solution = "Check for infinitely growing lists, strings, or unoptimized large datasets.";
  }

  return { rootCause, solution };
};